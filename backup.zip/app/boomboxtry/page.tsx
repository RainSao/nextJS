import Header from '@/components/mycomp/header'

function Mainpage() {
	return (
		<div>
			<Header />
		</div>
	)
}

export default Mainpage
