function Header() {
	return (
		<div className='flex justify-between'>
			<div className='bg-slate-400'>
				<img src='' alt='' />
				<p>user</p>
			</div>
			<div>
				<p>гав</p>
			</div>
			<div className='bg-slate-500'>
				<button>Играть</button>
				<button>Выйти</button>
			</div>
		</div>
	)
}

export default Header
